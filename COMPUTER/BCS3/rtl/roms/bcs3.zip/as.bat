@echo off
set file=%1
if "%1"=="" set file=bcs33
set bin=..\..\hobby\as\bin
%bin%\as.exe -L %file%.asm
%bin%\p2bin.exe -r $-$ "%file%.p"

%bin%\bdiff %file%.bin %file%.rom
