$infile = $ARGV[0] || 'bcs32zg.bin';

open IN, "<$infile";
binmode IN;

$char = 0;

until (eof IN) {
	read IN, $row, 8;
	printchar ($row);
	$char++;
	#last if $ln++ > 4;
}

close IN;


sub printchar {
	my $code=shift;
	
	printf "; Char %.2X %s\n", $char, $char < 32?'':"(".chr($char).")";

	my @bytes = unpack "B8"x8, $code;
#	print "@bytes\n";
	
	# Transponieren
#	my @tbytes;
#	for ($i=0; $i<8; $i++) {
#		for ($j=0; $j<8; $j++) {
#			$tbytes[$i] .= substr($bytes[$j],$i,1);
#		}
#	}
	
	
	#print "$code - @bytes\n";
	
	print "\tDB\t", join (", ", map ("${_}B", @bytes)), "\n";
	print "\n";

	foreach (@bytes) {
		tr/01/ #/;
	}

	# Zeilenreihenfolge ist 8,1,2,..7
	for ($i=1;$i<8;$i++) {
		print ";\t\t\"",@bytes[$i],"\"\n";
	}
	print ";\t\t\"",@bytes[0],"\"\n";

	print "\n";
}
